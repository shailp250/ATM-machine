

public class ATMexception extends Exception
{
    
	private static final long serialVersionUID = 1L;

	/**
     * Creates a new instance of ATMComputerException
     */
    public ATMexception(String reason) 
    {
        super(reason);
    }
    
}